# Luxe Theme Readme

Thanks for your purchase!

This theme was inspirate on serveral feedback that I received during weeks from users, so I decided to design my own version theme based-on the  "elegantTheme" from original Author.

## Instructions

1. You need upload "LuxeTemplate.zip" inside "modules" Folder on your server / localhost then decompress it.
2. You need repeat previous step but this time content from "luxe.zip" go inside "Public" folder.



Done! Now You can select theme inside Admin site settings dashboard.

I'm open to your feedback, or If you found any bug, send me a email to ux.aleks@gmail.com

Greetings 👋